package com.ahmadabuhasan.submission.submission

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
